/**
  * Irmak Kavasoglu
  * 2013400090
  */

For detailed explanation about the project, please refer to the project report.

To run the executable;
Make sure that there is a folder containing files 1.txt, 2.txt, ..., 1000.txt. 

Run the executable by using this command:
java -jar /path/to/directory/runnable.jar /path/to/dataset/directory 1.txt

replace 1.txt with any other document name to get its probability result list.
