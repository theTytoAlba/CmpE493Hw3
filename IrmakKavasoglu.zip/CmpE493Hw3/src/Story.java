import java.util.ArrayList;

public class Story {
	ArrayList<String> sentences = new ArrayList<>();
	ArrayList<String> summary = new ArrayList<>();
}
